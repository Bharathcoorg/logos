
#![cfg_attr(not(feature = "std"), no_std, no_main)]

#[ink::contract]
mod channel_manager {
    use ink::storage::Mapping;

    #[ink(storage)]
    pub struct ChannelManager {
        channels: Mapping<u64, Channel>,
        next_channel_id: u64,
    }

    #[derive(scale::Encode, scale::Decode, Clone)]
    #[cfg_attr(feature = "std", derive(Debug))]
    pub struct Channel {
        owner: AccountId,
        name: String,
        region: String,
        content_list: Vec<Content>,
    }

    #[derive(scale::Encode, scale::Decode, Clone)]
    #[cfg_attr(feature = "std", derive(Debug))]
    pub struct Content {
        playback_id: String,
        supabase_id: String,
        timestamp: Timestamp,
    }

    #[ink(event)]
    pub struct ChannelCreated {
        #[ink(topic)]
        channel_id: u64,
        owner: AccountId,
    }

    #[ink(event)]
    pub struct ContentAdded {
        #[ink(topic)]
        channel_id: u64,
        playback_id: String,
    }

    impl ChannelManager {
        #[ink(constructor)]
        pub fn new() -> Self {
            Self {
                channels: Mapping::default(),
                next_channel_id: 0,
            }
        }

        #[ink(message)]
        pub fn create_channel(&mut self, name: String, region: String) -> u64 {
            let id = self.next_channel_id;
            let channel = Channel {
                owner: self.env().caller(),
                name,
                region,
                content_list: Vec::new(),
            };
            self.channels.insert(id, &channel);
            self.next_channel_id += 1;
            self.env().emit_event(ChannelCreated {
                channel_id: id,
                owner: self.env().caller(),
            });
            id
        }

        #[ink(message)]
        pub fn add_content(
            &mut self,
            channel_id: u64,
            playback_id: String,
            supabase_id: String,
        ) -> Result<(), Error> {
            let mut channel = self.channels.get(channel_id).ok_or(Error::ChannelNotFound)?;
            if channel.owner != self.env().caller() {
                return Err(Error::NotChannelOwner);
            }
            channel.content_list.push(Content {
                playback_id: playback_id.clone(),
                supabase_id,
                timestamp: self.env().block_timestamp(),
            });
            self.channels.insert(channel_id, &channel);
            self.env().emit_event(ContentAdded {
                channel_id,
                playback_id,
            });
            Ok(())
        }

        #[ink(message)]
        pub fn get_channel(&self, channel_id: u64) -> Option<Channel> {
            self.channels.get(channel_id)
        }
    }

    #[derive(scale::Encode, scale::Decode)]
    #[cfg_attr(feature = "std", derive(Debug))]
    pub enum Error {
        ChannelNotFound,
        NotChannelOwner,
    }
}
