#![cfg_attr(not(feature = "std"), no_std, no_main)]

#[ink::contract]
mod funding {
    use ink::storage::Mapping;

    #[ink(storage)]
    pub struct Funding {
        proposals: Mapping<u64, Proposal>,
        next_proposal_id: u64,
        approved_budget: Mapping<AccountId, Balance>,
    }

    #[derive(scale::Encode, scale::Decode, Clone)]
    #[cfg_attr(feature = "std", derive(Debug))]
    pub struct Proposal {
        commissioner: AccountId,
        budget: Balance,
        status: ProposalStatus,
    }

    #[derive(scale::Encode, scale::Decode, Clone)]
    #[cfg_attr(feature = "std", derive(Debug))]
    pub enum ProposalStatus {
        Pending,
        Approved,
        Rejected,
    }

    #[ink(event)]
    pub struct ProposalCreated {
        #[ink(topic)]
        proposal_id: u64,
        commissioner: AccountId,
        budget: Balance,
    }

    #[ink(event)]
    pub struct ProposalApproved {
        #[ink(topic)]
        proposal_id: u64,
        allocated_budget: Balance,
    }

    impl Funding {
        #[ink(constructor)]
        pub fn new() -> Self {
            Self {
                proposals: Mapping::default(),
                next_proposal_id: 0,
                approved_budget: Mapping::default(),
            }
        }

        #[ink(message, payable)]
        pub fn create_proposal(&mut self, budget: Balance) -> Result<u64, Error> {
            let proposal_id = self.next_proposal_id;
            let transferred = self.env().transferred_balance();

            if transferred < budget {
                return Err(Error::InsufficientDeposit);
            }

            self.proposals.insert(
                proposal_id,
                &Proposal {
                    commissioner: self.env().caller(),
                    budget,
                    status: ProposalStatus::Pending,
                },
            );
            self.next_proposal_id += 1;

            self.env().emit_event(ProposalCreated {
                proposal_id,
                commissioner: self.env().caller(),
                budget,
            });
            Ok(proposal_id)
        }

        #[ink(message)]
        pub fn approve_proposal(&mut self, proposal_id: u64) -> Result<(), Error> {
            let mut proposal = self.proposals.get(proposal_id).ok_or(Error::ProposalNotFound)?;
            if proposal.status != ProposalStatus::Pending {
                return Err(Error::InvalidStatus);
            }

            proposal.status = ProposalStatus::Approved;
            self.proposals.insert(proposal_id, &proposal);

            let current_budget = self.approved_budget.get(proposal.commissioner).unwrap_or(0);
            self.approved_budget.insert(proposal.commissioner, &(current_budget + proposal.budget));

            self.env().emit_event(ProposalApproved {
                proposal_id,
                allocated_budget: proposal.budget,
            });
            Ok(())
        }

        #[ink(message)]
        pub fn get_approved_budget(&self, account: AccountId) -> Balance {
            self.approved_budget.get(account).unwrap_or(0)
        }
    }

    #[derive(scale::Encode, scale::Decode)]
    #[cfg_attr(feature = "std", derive(Debug))]
    pub enum Error {
        ProposalNotFound,
        InsufficientDeposit,
        InvalidStatus,
    }
}
