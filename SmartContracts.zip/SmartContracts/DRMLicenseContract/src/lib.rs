#![cfg_attr(not(feature = "std"), no_std, no_main)]

#[ink::contract]
mod drm_license {
    use ink::storage::Mapping;

    #[ink(storage)]
    pub struct DRMLicense {
        owners: Mapping<u64, AccountId>,
        content_map: Mapping<u64, ContentMetadata>,
        next_token_id: u64,
    }

    #[derive(scale::Encode, scale::Decode, Clone)]
    #[cfg_attr(feature = "std", derive(Debug))]
    pub struct ContentMetadata {
        playback_id: String,
        supabase_id: String,
        license_fee: Balance,
    }

    #[ink(event)]
    pub struct LicenseMinted {
        #[ink(topic)]
        token_id: u64,
        owner: AccountId,
        playback_id: String,
    }

    impl DRMLicense {
        #[ink(constructor)]
        pub fn new() -> Self {
            Self {
                owners: Mapping::default(),
                content_map: Mapping::default(),
                next_token_id: 0,
            }
        }

        #[ink(message, payable)]
        pub fn mint_license(
            &mut self,
            playback_id: String,
            supabase_id: String,
            license_fee: Balance,
        ) -> Result<u64, Error> {
            let transferred_balance = self.env().transferred_balance();
            if transferred_balance < license_fee {
                return Err(Error::InsufficientPayment);
            }

            let token_id = self.next_token_id;
            self.owners.insert(token_id, &self.env().caller());
            self.content_map.insert(
                token_id,
                &ContentMetadata {
                    playback_id: playback_id.clone(),
                    supabase_id,
                    license_fee,
                },
            );
            self.next_token_id += 1;

            self.env().emit_event(LicenseMinted {
                token_id,
                owner: self.env().caller(),
                playback_id,
            });
            Ok(token_id)
        }

        #[ink(message)]
        pub fn get_license_details(&self, token_id: u64) -> Option<ContentMetadata> {
            self.content_map.get(token_id)
        }

        #[ink(message)]
        pub fn is_license_owner(&self, token_id: u64, account: AccountId) -> bool {
            self.owners.get(token_id) == Some(account)
        }
    }

    #[derive(scale::Encode, scale::Decode)]
    #[cfg_attr(feature = "std", derive(Debug))]
    pub enum Error {
        InsufficientPayment,
    }
}
